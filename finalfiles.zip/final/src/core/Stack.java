package core;
import static org.junit.Assert.assertEquals;

import java.util.ArrayList;

public class Stack<T> {
	ArrayList<T> stack;
	int top = 0;
	public Stack() {
		stack = new ArrayList<T>();
	}
	
	public void push(T data) {
		top++;
		stack.add(data);
	}
	
	public T pop() {
		T result = stack.get(top);
		stack.remove(top);
		top--;
		return result;
	}
	
	public T peek() {
		return stack.get(top);
	}
	
	public static void main(String[] args) {
		Stack<Integer> myStack = new Stack<Integer>();
		myStack.push(42);
		myStack.push(50);
		assert(myStack.pop() == 50);
		assert(myStack.peek() == 42);
		assert(myStack.pop() == 42);
	}
}
