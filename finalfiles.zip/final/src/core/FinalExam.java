package core;
import java.util.HashSet;
import java.util.function.*;
public class FinalExam {
	private static HashSet<String> names = new HashSet<String>();
	
	public static void main(String[] args) {
		Function<String, Boolean> ohDeer = reindeer -> names.add(reindeer);
		
		addToSleigh(ohDeer, "Dasher");
		addToSleigh(ohDeer, "Dancer");
		addToSleigh(ohDeer, "Francer");
		addToSleigh(ohDeer, "Rudolph");
		
		names.forEach(n->System.out.println(n) );

	}
	
	public static boolean addToSleigh( Function<String, Boolean> add, String deer) {
		return add.apply(deer);
	}
	
	public static boolean ex1(Function<String, String> f, int s) {
		f.apply(String.valueOf(s));
		return true;
	}
}
