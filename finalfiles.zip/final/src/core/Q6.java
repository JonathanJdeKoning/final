package core;
import java.nio.file.*;
import java.io.IOException;
import java.util.Collections;
import java.util.List;
public class Q6 {
	public static void main(String[] args) throws IOException {
		List<String> lines = Files.readAllLines(Paths.get("song.txt"));
		Collections.reverse(lines);
		for (String line : lines) {
			String reversed="";
			for (int j = line.length()-1; j > -1; j--) {
				reversed += line.charAt(j);
			}
			System.out.println(reversed);
		}
	}
}
