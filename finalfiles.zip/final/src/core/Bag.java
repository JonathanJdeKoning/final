package core;

public class Bag<T,U> {
	private T t = null;
	private U u = null;
	
	public void add(T t, U u) {
		this.t = t;
		this.u = u;
	} 
	
	public boolean contains(U u) {
		return (this.u.equals(u));
	}
	
	public boolean isEmpty() {
		return (t == null && u == null);
	}
	
	public void clear() {
		this.t = null;
		this.u = null;
	}
	
}
