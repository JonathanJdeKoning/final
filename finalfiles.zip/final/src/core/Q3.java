package core;
import java.io.IOException;
import java.nio.file.*;
import java.util.*; 
class Q3 {
	public static void main(String[] args) throws IOException {
		Scanner scan = new Scanner(System.in);
		System.out.println("Number of Days:");
		int days = Integer.parseInt(scan.nextLine());
		String filepath = "data.txt";
		List<String> lines = Files.readAllLines(Paths.get(filepath));

		for(int i =0; i< days; i++) {
			System.out.println(lines.get(i));
		}
	}
}
