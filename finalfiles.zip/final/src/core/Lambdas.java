package core;
import java.util.function.*;
public class Lambdas {
	public static void main(String[] args) {
		Function<Integer, Integer> doubleItAndGiveItToTheNextPerson = (n) -> (2*n);
		int res = doubleItAndGiveItToTheNextPerson.apply(5);
		System.out.println(res);
	}
}
