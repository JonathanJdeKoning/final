package core;
import java.awt.Color;
import java.util.ArrayList;
import java.util.Collections;
public class NintendoCharacter implements Comparable{
	private Color color;
	private String name;
	
	public NintendoCharacter ( Color outfitColor, String characterName) {
		this.color = outfitColor;
		this.name = characterName;
	}
	
	@Override
	public int compareTo(Object o) {
		return color.toString().compareTo( ((NintendoCharacter)o).color.toString() );
	}
	
	public String toString() {
		return name + " : "  + color.toString();
	}
	
	public static void main(String[] args) {
		NintendoCharacter m = new NintendoCharacter(Color.red, "Mario");
		NintendoCharacter l = new NintendoCharacter(Color.green, "Luigi");
		NintendoCharacter p = new NintendoCharacter(Color.magenta, "Peach");
		
		ArrayList<NintendoCharacter> chars = new ArrayList<NintendoCharacter>();
		
		chars.add(m);
		chars.add(l);
		chars.add(p);
		
		for(NintendoCharacter c : chars) {
			System.out.println(c);
		}
		
		Collections.sort(chars);
		
		for(NintendoCharacter c : chars) {
			System.out.println(c);
		}
		
		
	}
}
