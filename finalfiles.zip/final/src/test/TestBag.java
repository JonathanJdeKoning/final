package test;

import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;
import core.Bag;

public class TestBag {
	Bag<String, Integer> testBag;
	
	@Before
	public void beforeTest() {
		testBag = new Bag<String, Integer>();
	}
	@Test
	public void testAdd() {
		fail("Not yet implemented");
	}

	@Test
	public void testContains() {
		fail("Not yet implemented");
	}

	@Test
	public void testIsEmpty() {
		assert(testBag.isEmpty());
		testBag.add("Jonathan", 20);
		assertFalse(testBag.isEmpty());
	}
	
	@Test
	public void testClear() {
		testBag.add("Jonathan", 20);
		assert(testBag.contains(20));
		testBag.clear();
		assert(testBag.isEmpty());
	}

}
